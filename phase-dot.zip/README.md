# phase-dot
A basic itch.io game

Try it out here: https://randomgamingdev.itch.io/phase-dot

Avoid the red dots, collect the yellow ones and prepare for a suprise at level 10 :D

Controls:

Tap to use phase which allows you to phase through enemies

Let go to turn and go the opposite direction
